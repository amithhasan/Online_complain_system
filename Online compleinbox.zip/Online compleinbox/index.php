<?php require_once('header.php'); ?>
<br><br><br><br><br>
<head>
	<title>E-Compleain </title>
</head>
<div class="container">		
	<?php  
		if(isset($_SESSION['user_id']))
		{
			echo"<a class='navbar-brand' href='complaine.php'>
					<img src='images/p11.jpg' alt='Logo' style='width:300px;height:200px'>
				</a>";
		}
                                
        else
		{
			
			 echo"<a class='navbar-brand' >
					<img src='images/p11.jpg' alt='Logo' style='width:300px;height:200px'>
				</a>";
             echo "<h4> <a href='Login.php'>Please Login For Compleain</a> </h4>";
		}
    ?>	
</div>

<?php require_once('Footer.php'); ?>