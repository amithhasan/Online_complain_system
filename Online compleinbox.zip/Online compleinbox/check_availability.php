<?php 
require_once("config/connection.php");

//Code check id
if(!empty($_POST["user_id"])) 
{
	$result1 = mysqli_query($conn, "SELECT count(*) FROM student_info WHERE user_id='".$_POST["user_id"]."'");
	$row1 = mysqli_fetch_row($result1);
	$user_count = $row1[0];
	if($user_count>0) echo "<span style='color:red'> ID already exit .</span>";
	else echo "<span style='color:green'> ID Available.</span>";
}
// End id check
?>