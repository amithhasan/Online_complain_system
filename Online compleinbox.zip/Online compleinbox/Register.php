<?php require_once('header.php'); ?>	
<head>
    <script>
        function checkuseridAvailability() {
            $("#loaderIcon").show();
            jQuery.ajax({
                url: "check_availability.php",
                data: 'user_id=' + $("#user_id").val(),
                type: "POST",
                success: function(data) {
                    $("#id-availability-status").html(data);
                    $("#loaderIcon").hide();
                },
                error: function() {}
            });
        }
    </script>
</head>

<body>
    <div class="container">
        <div class="row">
            <div id="login-form">
                <form name='register' action='reg_done.php' method='post' autocomplete="off" accept-charset='UTF-8'>
                    <div class="col-sm-3"></div>
                    <div class="col-sm-6">
                        <div class="form-group">
                            <h2 class="">Register Page</h2> </div>
                        <div class="form-group">
                            <hr /> </div>
                        <div class="form-group">
                            <div class="input-group"> <span class="input-group-addon"><i class="fa fa-envelope-o fa-fw"></i></span>
                                <input type="text" name="user_id" id="user_id" onBlur="checkuseridAvailability()" value="" required class="form-control" placeholder="Your ID" maxlength="15" /> </div> <span id="id-availability-status"></span> </div>
                        <div class="form-group">
                            <div class="input-group"> <span class="input-group-addon"><i class="fa fa-user-circle fa-fw"> </i></span>
                                <input type="txt" name="name" required class="form-control" placeholder="Enter Name" maxlength="50" /> </div>
                        </div>
                        <div class="form-group">
                            <select class="form-control" required name="semester">
                                <option value="" selected="selected">Semester</option>
                                <option value="1st">1st</option>
                                <option value="2nd">2nd</option>
                                <option value="3rd">3rd</option>
                                <option value="4th">4th</option>
                                <option value="5th">5th</option>
                                <option value="6th">6th</option>
                                <option value="7th">7th</option>
                                <option value="8th">8th</option>
                                <option value="9th">9th</option>
                                <option value="10th">10th</option>
                                <option value="11th">11th</option>
                                <option value="12th">12th</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <div class="input-group"> <span class="input-group-addon"><i class="fa fa-user fa-fw"> </i></span>
                                <input type="text" name="batch" value="" required class="form-control" placeholder="Your Batch" /> </div>
                        </div>
                        <div class="form-group">
                            <div class="input-group"> <span class="input-group-addon"><i class="fa fa-key fa-fw"></i></span>
                                <input type="text" required name="dept" class="form-control" placeholder="Your Department" /> </div>
                        </div>
                        <div class="form-group">
                            <div class="input-group"> <span class="input-group-addon"><i class="fa fa-key fa-fw"></i></span>
                                <input type="password" required name="password" class="form-control" placeholder="Enter Password" /> </div>
                        </div>
                        <hr/>
                        <div class="form-group">
                            <button type="submit" class="btn btn-block btn-primary" name="Submit">Sign Up</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>                                             
<?php require_once('Footer.php'); ?>
