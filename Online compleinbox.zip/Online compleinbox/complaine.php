<?php require_once('header.php'); ?>	
<?php 
    if(logged_in())
    {
    $Name=$_SESSION['name'];
    $pass=$_SESSION['password'];   
    $pid= $_SESSION['user_id'];
    
    }
	else
		header('location:login.php');
	
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Complain Box </title>
</head>
<br>
<br>
<br>
	<div class='container'>
                    <div class="row complain">
                        <div class="col-sm-3"></div>
                        <div class="col-sm-6">
                            <h2>Tell Us Your Complain:</h2>
                            <form method="post" action="sendcomplain.php">
                                <br>
                                <br>
                                <div class='form-group'>
                                    <input type='text' class='form-control' required name='concerned_area' placeholder='Concerned Area...'> 
								</div>
								<div class='form-group'>
                                    <input type='text' class='form-control' required name='phone' maxlength="11" placeholder='Phone....'> 
								</div>
                                <div class='form-group'>
                                    <input type='email' class='form-control' required name='email' placeholder='Email....'> 
								</div>
								<div class='form-group'>
                                    <input type='text' class='form-control' required name='location' placeholder='Location....'> 
								</div>
                                
                                <div class='form-group'>
                                    <input type='text' class='form-control' required name='subject' placeholder='Subject of Complain....'> </div>
                                <div class='form-group'>
                                    <textarea class='form-control' rows='6' required class='form-control' name='message' placeholder='Your Complain....'> </textarea>
                                </div>
                                <div class='form-group'>
                                    <button type='submit' id='button' value='Submit' class='btn btn-block btn-primary' name='submit'>Submit</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class='col-sm-3'></div>
     </div>	
<?php require_once('Footer.php'); ?>