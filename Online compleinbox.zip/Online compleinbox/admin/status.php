<?php
	session_start();
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php


$cid=$_GET['cid'];
$sid=$_GET['sid'];
$aid=$_SESSION['id'];

$con = mysqli_connect("localhost","root");
mysqli_select_db("project", $con);




    $insert_query="INSERT INTO `approve`(`id`, `complain_id`, `user_id`, `admn_id`) VALUES ('','$cid', '$sid', '$aid') "; 
    mysqli_query($insert_query,$con);
    $update_query="Update complain_box set status='Confirm' where user_id='".$_GET['sid']."'"; 
    mysqli_query($update_query,$con);




mysqli_close($con);
echo '<script type="text/javascript">alert("Employer Request Confirmed");window.location=\'manage-users.php\';</script>';
?>
</body>
</html>


