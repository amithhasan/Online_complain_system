<?php
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "project";

	// Create connection
	$bd = mysqli_connect($servername, $username, $password, $dbname);
	// Check connection
	if (!$bd) {
	  die("Connection failed: " . mysqli_connect_error());
	}