<?php require_once("session.php"); ?>
<?php require_once("functions.php"); ?>
<?php 
    if(logged_in())
    {
    $Name=$_SESSION['name'];
    $pass=$_SESSION['password'];   
    $pid= $_SESSION['user_id'];
    
    }
	
?>
 <!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="lib/bootstrap.css">
    <link rel="stylesheet" href="lib/style.css">
    <link rel="stylesheet" href="lib/font-awesome.min.css" >
    <script src="lib/jquery.js"></script>
    <script src="lib/bootstrap.min.js"></script>
</head>

<body>
    <nav class="navbar navbar-default navbar-fixed-top">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
                <a href="index.php"><img src="images/vu.png" alt="Logo" style="width:100px;"></a>
            </div>
            <div id="navbar" class="navbar-collapse collapse">
                <ul class="nav navbar-nav">
                    <li><a href="index.php"><i class="fa fa-home fa-fw"></i>&nbsp;Home</a></li>
                    <li><a href="aboutus.php"> About</a></li>
                    <li><a href="Contact.php"> Contact</a></li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle " data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> <i class="fa fa-user"></i>&nbsp;
                            <?php  
								if(isset($_SESSION['user_id']))
									{
										echo $Name;
									}
                                
                                else
                                    echo 'Not in';

                            ?> &nbsp;<span class='caret'></span> </a>
                        <ul class="dropdown-menu">
                            <?php
							if(isset($_SESSION['user_id']))
							{
								echo "<li><a href='log-out.php'><i class='fa fa-sign-out fa-fw'></i>&nbsp; Log Out</a></li>";
							}
						
							else
							{
								echo "<li><a href='Login.php'><i class='fa fa-pencil fa-fw'></i>&nbsp; Log In</a></li>";
								echo "<li><a href='Register.php'><i class='fa fa-pencil fa-fw'></i>&nbsp; Register</a></li>";								
							}																								
							
						?>
                        </ul>
                    </li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="Admin/"> Admin</a></li>
                </ul>
            </div>
        </div>
    </nav>