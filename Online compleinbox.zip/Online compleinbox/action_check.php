<?php require_once("config/connection.php"); ?>
    <?php

session_start();


	$login = mysqli_query($conn, "SELECT * FROM student_info WHERE user_id = '".$_POST['user_id']."' and password='".$_POST['password']."'");

	if (mysqli_num_rows($login) == 1) 
	{
		$row=mysqli_fetch_array($login);
			$_SESSION['name'] =     $row['name'];
			$_SESSION['password']=  $_POST['password'];
			$_SESSION['user_id']=   $row['user_id'];
			echo"<script>alert('Successfully Login'); window.location='index.php'</script> ";
			  
	}
	else 
	{ 
			$_SESSION['username'] = NULL;
			$_SESSION['password']=NULL;
			$_SESSION['user_id']=NULL;
			echo"<script>alert('Error Username Or Password'); window.location='Login.php'</script> ";
	}


?>