<?php
session_start();
if ( !isset($_SESSION['user_id']) || !isset($_SESSION['password']) ) {
 header('Location: index');
}
?>
<?php


session_start();
unset($_SESSION['user_id']);
session_destroy();
header('Location: index.php');

?>
