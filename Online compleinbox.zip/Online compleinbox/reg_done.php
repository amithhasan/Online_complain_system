<?php
    $servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "project"; //Database name

	// Create connection
	$conn = mysqli_connect($servername, $username, $password, $dbname);
	// Check connection
	if (!$conn) {
		die("Connection failed: " . mysqli_connect_error());
	}
	
	$user_id =  $_POST['user_id'];
	$name =     $_POST['name'];
	$semester = $_POST['semester'];
	$batch  =   $_POST['batch'];
	$dept  =    $_POST['dept'];	
	$password = $_POST['password'];   

			
	$sql= "INSERT INTO `student_info`(`id`, `user_id`, `name`,  `semester`, `batch`,   `dept`,   `password`) VALUES
									 ('',   '$user_id', '$name', '$semester', '$batch', '$dept', '$password')";
	

	if (mysqli_query($conn, $sql)) 
	{
		echo "<script>alert('Successfully registered!'); window.location='Login.php'</script>";
	} 
	else {
		echo "Error: " . $sql . "<br>" . mysqli_error($conn);
	}

	mysqli_close($conn);
?>