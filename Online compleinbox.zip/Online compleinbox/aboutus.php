<?php require_once('header.php'); ?>
<head>
	<title>About Us </title>
</head>
<?php require_once('Footer.php'); ?>