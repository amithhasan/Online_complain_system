<?php require_once('header.php'); ?>
<?php 
    if(logged_in())
    {
    $Name=$_SESSION['name'];
    $pass=$_SESSION['password'];   
    $pid= $_SESSION['user_id'];
	header('location:index.php');
    
    }
	
?>
<head>
	<title>Login </title>
</head>
    <div class="container">
        <div id="login-form">
            <form role="form" action='action_check.php' method="post">
                <div class="col-sm-3"></div>
                <div class="col-md-6">
                    <div class="form-group">
                        <h2 class="">Sign In.</h2> </div>
                    <div class="form-group">
                        <hr /> </div>
                    <div class="form-group">
                        <div class="input-group"> <span class="input-group-addon"><i class="fa fa-envelope-o fa-fw"></i></span>
                            <input type="text" required name="user_id" class="form-control" placeholder="ID" maxlength="15" /> </div>
                    </div>
                    <div class="form-group">
                        <div class="input-group"> <span class="input-group-addon"><i class="fa fa-key fa-fw"></i></span>
                            <input type="password" required name="password" class="form-control" placeholder="Password" /> </div>
                    </div>
                    <div class="form-group">
                        <hr /> </div>
                    <div class="form-group">
                        <button type="submit" value="login" class="btn btn-block btn-primary" name="btn-login">Sign In</button>
                    </div>
                    <div class="form-group">
                        <hr /> </div>
                    <div class="form-group"> <a href="Register.php">Sign Up Here...</a> </div>
                </div>
            </form>
        </div>
    </div>
    <?php require_once('Footer.php'); ?>