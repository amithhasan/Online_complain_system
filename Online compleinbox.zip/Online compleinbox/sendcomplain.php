<?php require_once("session.php"); ?>
<?php require_once("functions.php"); ?>
<?php 
    if(logged_in())
    {
		$Name=$_SESSION['name'];
		$pass=$_SESSION['password'];   
		$user_id= $_SESSION['user_id'];
    
    }

    $servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "project"; //Database name

	// Create connection
	$conn = mysqli_connect($servername, $username, $password, $dbname);
	// Check connection
	if (!$conn) {
		die("Connection failed: " . mysqli_connect_error());
	}
	

	$concerned_area = $_POST['concerned_area'];
	$phone  =   $_POST['phone'];
	$email  =   $_POST['email'];	
	$location = $_POST['location'];   
	$subject =  $_POST['subject'];   
	$message =  $_POST['message'];   
	$status =  "Pending";   
	$date=date('d-m-y');  

			
	$sql= "INSERT INTO `complain_box`(`id`, `user_id`,  `name`,  `concerned_area`,  `phone`,  `email`,  `location`, `subject`,  `message`,  `status`, `date`)
							   VALUES('',  '$user_id', '$Name', '$concerned_area', '$phone', '$email', '$location', '$subject','$message', '$status', '$date')";
	

	if (mysqli_query($conn, $sql)) 
	{
		echo "<script>alert('Successfully Send!'); window.location='index.php'</script>";
	} 
	else {
		echo "Error: " . $sql . "<br>" . mysqli_error($conn);
	}

	mysqli_close($conn);
?>